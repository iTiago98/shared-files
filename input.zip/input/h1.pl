for (i=1; i<10; i=i+1) 
     x = x+i;
print(x);
