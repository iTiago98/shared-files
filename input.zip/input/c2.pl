if ( a == 0 ) {
    if (b <= a) {
        if (c >= a*b) 
            print (c);
    }
    a = -1;
    b = -1;
    c = -1;
}
print(a*b*c);
