public class ETD
{
	private String v, f;
	public ETD(String v, String f)
	{
		this.v = v;
		this.f = f;
	}

	public String v(){ return v; }
	public String f(){ return f; }
}
