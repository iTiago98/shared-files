public class Variable
{
  public static final String INT = "int";
	public static final String FLOAT = "float";
  public static final String CHAR = "char";
	public static final String ARR = "arr";
  public static final String CARR = "carr";
  public static final String STR = "str";

  public String name;
  public String type;
  public int size;
  public Variable(String n, String t, int s)
  {
    name = n;
    type = t;
    size = s;
  }
}
