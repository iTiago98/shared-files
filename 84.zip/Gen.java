import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

class Gen
{
	public static final String EOL = "10";

	public static final String ASIG = "asig";
	public static final String SUM = "sum";
	public static final String SUB = "sub";
	public static final String MUL = "mul";
	public static final String DIV = "div";
	public static final String RSUM = "rsum";
	public static final String RSUB = "rsub";
	public static final String RMUL = "rmul";
	public static final String RDIV = "rdiv";
	public static final String CSTI = "csti";
	public static final String CSTF = "cstf";
	public static final String ARGT = "argt";
	public static final String ARPT = "arpt";
	public static final String GOTO = "goto";
	public static final String IFEQ = "ifeq";
	public static final String IFLT = "iflt";
	public static final String LAB = "lab";
	public static final String PRNT = "prnt";
	public static final String PRNC = "prnc";
	public static final String WRTC = "wrtc";
	public static final String HALT = "halt";
	public static final String ERR = "err";

	public static void gc(String command, String arg1, String arg2, String arg3)
	{
		if(command.equals(ASIG))		PLXC.out.println(arg3 + " = " + arg1 + " ;");
		else if(command.equals(SUM))	PLXC.out.println(arg3 + " = " + arg1 + " + " + arg2 + " ;");
		else if(command.equals(SUB))	PLXC.out.println(arg3 + " = " + arg1 + " - " + arg2 + " ;");
		else if(command.equals(MUL))	PLXC.out.println(arg3 + " = " + arg1 + " * " + arg2 + " ;");
		else if(command.equals(DIV))	PLXC.out.println(arg3 + " = " + arg1 + " / " + arg2 + " ;");
		else if(command.equals(RSUM))	PLXC.out.println(arg3 + " = " + arg1 + " +r " + arg2 + " ;");
		else if(command.equals(RSUB))	PLXC.out.println(arg3 + " = " + arg1 + " -r " + arg2 + " ;");
		else if(command.equals(RMUL))	PLXC.out.println(arg3 + " = " + arg1 + " *r " + arg2 + " ;");
		else if(command.equals(RDIV))	PLXC.out.println(arg3 + " = " + arg1 + " /r " + arg2 + " ;");
		else if(command.equals(CSTI)) PLXC.out.println(arg3 + " = (int) " + arg1 + " ;");
		else if(command.equals(CSTF)) PLXC.out.println(arg3 + " = (float) " + arg1 + " ;");
		else if(command.equals(ARGT)) PLXC.out.println(arg3 + " = " + arg1 + "[" + arg2 + "] ;");
		else if(command.equals(ARPT)) PLXC.out.println(arg1 + "[" + arg2 + "] = " + arg3 + " ;");
		else if(command.equals(GOTO))	PLXC.out.println("goto " + arg3 + " ;");
		else if(command.equals(IFEQ))	PLXC.out.println("if (" + arg1 + " == " + arg2 + ") " + "goto " + arg3 + " ;");
		else if(command.equals(IFLT))	PLXC.out.println("if (" + arg1 + " < " + arg2 + ") " + "goto " + arg3 + " ;");
		else if(command.equals(LAB))	PLXC.out.println("label " + arg3 + " ;");
		else if(command.equals(PRNT))	PLXC.out.println("print " + arg3 + " ;");
		else if(command.equals(PRNC)) PLXC.out.println("printc " + arg3 + " ;");
		else if(command.equals(WRTC)) PLXC.out.println("writec " + arg3 + " ;");
		else if(command.equals(HALT))	PLXC.out.println("halt ;");
		else if(command.equals(ERR))	PLXC.out.println("error ;\n# " + arg3 + "\nhalt ;");
	}

	private static int label_count = 0;
	public static String newLabel()
	{
		return "l"+label_count++;
	}
	private static int var_count = 0;
	public static String newVar()
	{
		return "x"+var_count++;
	}
	private static int arr_count = 0;
	public static String newArr()
	{
		return "a"+arr_count++;
	}
	private static int str_count = 0;
	public static String newStr()
	{
		return "s"+str_count++;
	}

	private static int varNamesIndex = 0;
	private static List<Map<String, Variable>> varNames = new ArrayList<>();
	public static void addContext()
	{
		varNamesIndex++;
	}
	public static void rmContext()
	{
		varNamesIndex--;
		while(varNames.size()>varNamesIndex+1){
			varNames.remove(varNames.size()-1);
		}
	}
	public static void addVar(String original, String generated, String type, String size)
	{
		while(varNames.size()<varNamesIndex+1){
			varNames.add(new HashMap<String, Variable>());
		}
		if(varNames.get(varNamesIndex).get(original)==null)
			varNames.get(varNamesIndex).put(original, new Variable(generated, type, Integer.parseInt(size)));
		else
			gc(ERR, null, null, "variable ya declarada");
	}
	public static Variable getVarName(String original)
	{
		Variable res=null;
		int i = varNamesIndex;

		while(varNames.size()<varNamesIndex+1){
			varNames.add(new HashMap<String, Variable>());
		}

		if(varNames.size()>0){
			do{
				res = varNames.get(i).get(original);
				i--;
			}while(res==null && i>=0);
		}

		if(res == null) {
			gc(ERR, null, null, "variable no declarada");
			res = new Variable("0", Variable.INT, 0);
		}
		return res;
	}

	public static void checkArrayRange(String index, String size)
	{
		ETD aux = new ETD(Gen.newLabel(), Gen.newLabel());
		Gen.gc(Gen.IFLT, index, "0", aux.v());
		Gen.gc(Gen.IFLT, size, index, aux.v());
		Gen.gc(Gen.IFEQ, size, index, aux.v());
		Gen.gc(Gen.GOTO, null, null, aux.f());
		Gen.gc(Gen.LAB, null, null, aux.v());
		Gen.gc(Gen.ERR, null, null, "indice de array fuera de sus limites");
		Gen.gc(Gen.LAB, null, null, aux.f());
	}

	private static List<String> temp = new ArrayList<>();
	public static int addTemp(String num)
	{
		temp.add(num);
		return temp.size();
	}
	public static String getTemp(int i)
	{
		return temp.get(i);
	}
	public static void emptyTemp()
	{
		temp = new ArrayList<>();
	}

	public static Variable operation(String iop, String fop, Variable e1, Variable e2)
	{
		boolean fl = false;
		String x = newVar();

		if(e1.type.equals(Variable.INT)){
			if(e2.type.equals(Variable.INT)){
				gc(iop, e1.name, e2.name, x);
			}else{
				fl = true;
				String e1f = newVar();
				gc(CSTF, e1.name, null, e1f);
				gc(fop, e1f, e2.name, x);
			}
		}else{
			fl = true;
			if(e2.type.equals(Variable.FLOAT)){
				gc(fop, e1.name, e2.name, x);
			}else{
				String e2f = newVar();
				gc(CSTF, e2.name, null, e2f);
				gc(fop, e1.name, e2f, x);
			}
		}

		return new Variable(x, fl ? Variable.FLOAT : Variable.INT, 0);
	}
}
