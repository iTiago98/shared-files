class Gen
{
	public static final String ASIG = "ASIG";
	public static final String SUM = "SUM";
	public static final String SUB = "SUB";
	public static final String MUL = "MUL";
	public static final String DIV = "DIV";
	public static final String GOTO = "GOTO";
	public static final String IFEQ = "IFEQ";
	public static final String IFLT = "IFLT";
	public static final String LAB = "LAB";
	public static final String PRNT = "PRNT";
	public static final String HALT = "HALT";
	
	public static void gc(String command, String arg1, String arg2, String arg3)
	{
		if(command.equals(ASIG)){
			PLC.out.println(arg3 + " = " + arg1 + " ;");
		}else if(command.equals(SUM)){
			PLC.out.println(arg3 + " = " + arg1 + " + " + arg2 + " ;");
		}else if(command.equals(SUB)){
			PLC.out.println(arg3 + " = " + arg1 + " - " + arg2 + " ;");
		}else if(command.equals(MUL)){
			PLC.out.println(arg3 + " = " + arg1 + " * " + arg2 + " ;");
		}else if(command.equals(DIV)){
			PLC.out.println(arg3 + " = " + arg1 + " / " + arg2 + " ;");
		}else if(command.equals(GOTO)){
			PLC.out.println("goto " + arg3 + " ;");
		}else if(command.equals(IFEQ)){
			PLC.out.println("if (" + arg1 + " == " + arg2 + ") " + "goto " + arg3 + " ;");
		}else if(command.equals(IFLT)){
			PLC.out.println("if (" + arg1 + " < " + arg2 + ") " + "goto " + arg3 + " ;");
		}else if(command.equals(LAB)){
			PLC.out.println("label " + arg3 + " ;");
		}else if(command.equals(PRNT)){
			PLC.out.println("print " + arg3 + " ;");
		}else if(command.equals(HALT)){
			PLC.out.println("halt ;");
		}
	}

	private static int label_count = 0;
	public static String newLabel()
	{
		return "l"+label_count++;	
	}

	private static int var_count = 0;
	public static String newVar()
	{
		return "x"+var_count++;
	}
}